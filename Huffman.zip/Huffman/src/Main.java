import java.util.HashMap;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        HashMap<String, String> binary = new HashMap<String, String>();
        Scanner input =new Scanner(System.in);
        System.out.println("dizini GİRİN");
        System.out.println("bu sistem e,n,r,s harfleri içindir");
        String metin=input.nextLine();


        char karakter1='e';
        int countE = 0;
        char karakter2='n';
        int countN=0;
        char karakter3='r';
        int countR=0 ;
        char karakter4='s';
        int countS=0;

        /// GİRİLEN METİNDE HER KARAKTERDEN LAÇ TANE VAR ONU BULUYORUM
        for(int i =0;i<metin.length();i++) {
            if(metin.charAt(i)==karakter1) {
                countE++;

            }
            else if(metin.charAt(i)==karakter2) {
                countN++;
            }
            else if(metin.charAt(i)==karakter3) {
                countR++;

            }
            else if(metin.charAt(i)==karakter4) {
                countS++;
            }


        }

        String[] karakterler= new String[4];
        karakterler[0]="e";
        karakterler[1]="n";
        karakterler[2]="r";
        karakterler[3]="s";

        int[] tekrarlar=new int[4];
        tekrarlar[0]=countE;
        tekrarlar[1]=countN;
        tekrarlar[2]=countR;
        tekrarlar[3]=countS;
        int uzunluk=tekrarlar.length;


        // EN ÇOK TEKRAR EDEN KARAKTERE GÖRE SIRALAMA YAPTIM İNSERTİON-SORT KULLANDIM


        for(int i =1; i<uzunluk; i++) {
            for(int k=i ;k>0 ; k-- ) {
                if(tekrarlar[k]<tekrarlar[k-1]) {
                    int gecici=tekrarlar[k];
                    tekrarlar[k]=tekrarlar[k-1];
                    tekrarlar[k-1]=gecici;
                    String  gecici1 = karakterler[k];
                    karakterler[k]=karakterler[k-1];
                    karakterler[k-1]=gecici1;
                }
            }
        }
        //BİNARY KARŞILIKLARINI VERDİM
        //SIRALI BİR ŞEKİLDE
        binary.put(karakterler[0], "00");
        binary.put(karakterler[1], "01");
        binary.put(karakterler[2], "10");
        binary.put(karakterler[3], "11");


        //BİNARY KARŞILIKLARINI YAZDIRDIM
        for(int i=0;i<metin.length();i++){
            System.out.print(metin.subSequence(i, i+1)+"  ");

        }
        System.out.println("" );
        for(int i=0;i<metin.length();i++){
            System.out.print(binary.get(metin.subSequence(i,i+1))+" ");

        }



    }

}


